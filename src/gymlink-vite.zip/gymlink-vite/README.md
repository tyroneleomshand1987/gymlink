# GymLink — Vite + React + Supabase

## Vercel settings
Framework: Vite
Build command: `npm run build`
Output directory: `dist`
Install command: `npm install`

## Environment variables
`VITE_SUPABASE_URL` = your Supabase project URL
`VITE_SUPABASE_ANON_KEY` = your Supabase publishable/anon key

Do not commit real environment secrets to GitHub.
